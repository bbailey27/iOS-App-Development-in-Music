//
//  ViewController.swift
//  EDM
//
//  Created by Bridget Bailey on 1/31/17.
//  Copyright © 2017 Bridget Bailey. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {
    
    var songName = "EDM"
    var songExt = "m4a"
    var songPlayer:AVAudioPlayer?
    var songLocation:URL?
    var bigImage:UIImage?
    var smallImage:UIImage?

    @IBOutlet weak var panningSlider: UISlider!
    @IBOutlet weak var volumeSlider: UISlider!
    @IBOutlet weak var animationImageView: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        songLocation = Bundle.main.url(forResource: songName, withExtension: songExt)
        
        do {
            try songPlayer = AVAudioPlayer(contentsOf: songLocation!)
            // ! means
        } catch let error as NSError {
            print(error.localizedDescription)
        }

        songPlayer?.prepareToPlay()

        bigImage = UIImage(named: "Big")
        smallImage = UIImage(named: "Small.png")
        let images: [UIImage] = [bigImage!,smallImage!]
        animationImageView.animationImages = images
        animationImageView.animationDuration = 0.5455
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func playMusicAction(_ sender: UIButton) {
        songPlayer?.play()
        animationImageView.startAnimating()
    }
    
    @IBAction func pauseMusicAction(_ sender: UIButton) {
        songPlayer?.pause()
        animationImageView.stopAnimating()
    }
    
    @IBAction func changeVolumeAction(_ sender: UISlider) {
        songPlayer?.volume = volumeSlider.value
    }
    
    @IBAction func startOverMusicAction(_ sender: UIButton) {
        songPlayer?.currentTime = 0.0
    }

    
}
